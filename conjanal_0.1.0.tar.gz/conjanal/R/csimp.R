#' scenario data for conjanal
#'
#' @name csimp
#' @docType data
#' @keywords data
NULL
