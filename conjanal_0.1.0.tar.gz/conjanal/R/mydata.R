#' sample data for conjanal
#'
#' @name mydata
#' @docType data
#' @keywords data
NULL
